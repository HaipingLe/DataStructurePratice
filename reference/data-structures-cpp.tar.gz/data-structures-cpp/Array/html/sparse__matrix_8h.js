var sparse__matrix_8h =
[
    [ "TriTuple", "structTriTuple.html", "structTriTuple" ],
    [ "SparseMatrix", "classSparseMatrix.html", "classSparseMatrix" ],
    [ "SparseMatrix", "classSparseMatrix.html", "classSparseMatrix" ],
    [ "operator<<", "sparse__matrix_8h.html#a6d6e4a8d9f92eb274bff5296cdd219e8", null ],
    [ "operator<<", "sparse__matrix_8h.html#a25cf4feb05256969d0cbdca02ee5a75b", null ],
    [ "operator>>", "sparse__matrix_8h.html#a1973a443914092fbe4790688877d2884", null ],
    [ "Swap", "sparse__matrix_8h.html#ace7fcf05dadf1b1f00c6c3d6ec4de1e7", null ]
];