﻿/*!
 * @file test.h
 * @author CyberDash计算机考研, cyberdash@163.com(抖音id:cyberdash_yuan)
 * @brief 测试.h文件
 * @version 0.2.1
 * @date 2021-07-14
 */

#ifndef CYBER_DASH_TREE_HEAP_TEST_H
#define CYBER_DASH_TREE_HEAP_TEST_H


// 测试-堆
void TestHeap();


#endif // CYBER_DASH_TREE_HEAP_TEST_H
