﻿/*!
 * @file test.h
 * @author CyberDash计算机考研, cyberdash@163.com(抖音id:cyberdash_yuan)
 * @brief 测试h文件
 * @version 0.2.1
 * @date 2021-05-29
 */

#ifndef CYBER_DASH_SEARCH_DATA_LIST_TEST_H
#define CYBER_DASH_SEARCH_DATA_LIST_TEST_H


// 测试-线性表搜索-顺序搜索和二分搜索
void TestSearch();


#endif // CYBER_DASH_SEARCH_DATA_LIST_TEST_H
