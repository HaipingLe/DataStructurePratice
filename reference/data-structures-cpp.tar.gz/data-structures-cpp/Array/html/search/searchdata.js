var indexSectionsWithContent =
{
  0: "cefmorstv~",
  1: "st",
  2: "mst",
  3: "cefmorst~",
  4: "cersv",
  5: "o"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "related"
};

var indexSectionLabels =
{
  0: "全部",
  1: "类",
  2: "文件",
  3: "函数",
  4: "变量",
  5: "友元"
};

