var searchData=
[
  ['value',['value',['../structTriTuple.html#a27e6b5fc24fc5b64046a5102fd52ebc4',1,'TriTuple']]]
];
