var structTriTuple =
[
    [ "operator=", "structTriTuple.html#a194896985cf967e7e8646e96bddf9ae4", null ],
    [ "col", "structTriTuple.html#a62740a8464d948136a9976a77b1a598c", null ],
    [ "row", "structTriTuple.html#a8fc66c032d1bbdd1dcfc925622eba175", null ],
    [ "value", "structTriTuple.html#a27e6b5fc24fc5b64046a5102fd52ebc4", null ]
];